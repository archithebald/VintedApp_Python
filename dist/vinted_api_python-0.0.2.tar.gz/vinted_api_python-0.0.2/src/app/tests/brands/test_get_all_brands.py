from src.app import Vinted

app = Vinted.Vinted()

print(app.get_all_brands())