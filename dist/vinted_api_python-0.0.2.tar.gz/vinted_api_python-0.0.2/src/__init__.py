print("Initializing project..")
print("Initialized ✅")