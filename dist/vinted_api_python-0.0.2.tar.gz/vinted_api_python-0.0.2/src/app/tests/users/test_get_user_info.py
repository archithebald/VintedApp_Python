from src.app import Vinted

app = Vinted.Vinted()

print(app.get_user_info("34311177"))