from src.app import Vinted

app = Vinted.Vinted()

print(app.get_brand(brand_name="Jordan"))