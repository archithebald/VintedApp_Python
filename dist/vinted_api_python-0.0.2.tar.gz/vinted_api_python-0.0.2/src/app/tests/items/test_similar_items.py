from src.app import Vinted

app = Vinted.Vinted()

print(app.similar_items("4551573809"))