from src.app import Vinted

app = Vinted.Vinted()

print(app.get_item_details(item_id="4596708317"))